package com.musicfly.backend.models;

public enum RoleList {
    ROLE_USER,
    ROLE_ARTIST,
    ROLE_ADMIN
}
